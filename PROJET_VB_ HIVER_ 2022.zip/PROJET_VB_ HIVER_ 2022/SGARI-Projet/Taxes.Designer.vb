﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Taxes
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Combotaxes = New System.Windows.Forms.ComboBox()
        Me.TextTaux = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Groupoperation = New System.Windows.Forms.GroupBox()
        Me.Groupoperation.SuspendLayout()
        Me.SuspendLayout()
        '
        'Combotaxes
        '
        Me.Combotaxes.FormattingEnabled = True
        Me.Combotaxes.Items.AddRange(New Object() {"TPS", "TVQ"})
        Me.Combotaxes.Location = New System.Drawing.Point(16, 57)
        Me.Combotaxes.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Combotaxes.Name = "Combotaxes"
        Me.Combotaxes.Size = New System.Drawing.Size(345, 24)
        Me.Combotaxes.TabIndex = 0
        '
        'TextTaux
        '
        Me.TextTaux.Location = New System.Drawing.Point(72, 121)
        Me.TextTaux.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextTaux.Name = "TextTaux"
        Me.TextTaux.Size = New System.Drawing.Size(155, 22)
        Me.TextTaux.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Lime
        Me.Button1.Location = New System.Drawing.Point(8, 30)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 30)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Valider"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Red
        Me.Button2.Location = New System.Drawing.Point(213, 30)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(113, 27)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "Annuler"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Groupoperation
        '
        Me.Groupoperation.Controls.Add(Me.Button1)
        Me.Groupoperation.Controls.Add(Me.Button2)
        Me.Groupoperation.Location = New System.Drawing.Point(16, 196)
        Me.Groupoperation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Groupoperation.Name = "Groupoperation"
        Me.Groupoperation.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Groupoperation.Size = New System.Drawing.Size(347, 70)
        Me.Groupoperation.TabIndex = 4
        Me.Groupoperation.TabStop = False
        '
        'Taxes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Silver
        Me.ClientSize = New System.Drawing.Size(379, 281)
        Me.Controls.Add(Me.Groupoperation)
        Me.Controls.Add(Me.TextTaux)
        Me.Controls.Add(Me.Combotaxes)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Taxes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Fiscalité"
        Me.Groupoperation.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Combotaxes As ComboBox
    Friend WithEvents TextTaux As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Groupoperation As GroupBox
End Class
